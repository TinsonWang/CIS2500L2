#include "functions.h"

void swap_output(struct foobarbaz** array, int a, int b)
{
    struct foobarbaz* temp = NULL;
    temp = array[a];
    array[a] = array[b];
    array[b] = temp;
}