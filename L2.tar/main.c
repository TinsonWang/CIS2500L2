#include <stdio.h>
#include <stdlib.h>
#include "functions.h"

int main(void)
{
    struct foobarbaz** container = NULL;
    container = many_foobarbaz();

    print_foobarbaz_array(container);

    /* The rand_double function is called using 0 and 19 because it will generate between 0 and 19 inclusive.
        If it was called using 0 and 20 and happened to generate 20, array[20] is not an existent element */
    int swap_point_1 = rand_double(0, 19);
    int swap_point_2 = rand_double(0, 19);

    /* Colloquially, we call the first struct printed as 1, the second as 2, and so on...
        However, because these numbers are being used as indices, one is being added to them to offset index 0. */
    printf("\nSwap point 1: %d\n", swap_point_1+1);
    printf("Swap point 2: %d\n\n", swap_point_2+1);

    swap_output(container, swap_point_1, swap_point_2);
    print_foobarbaz_array(container);

    int i;
    for (i = 0; i < 20; i++)
    {
        free(container[i]);
    }
    free(container);

    return 0;
}