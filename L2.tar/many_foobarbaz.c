#include "functions.h"

struct foobarbaz** many_foobarbaz(void)
{
    /*Initialize a pointer of pointers of type struct foobarbaz*/
    struct foobarbaz** container = NULL;
    /*This pointer of pointers will be allocated enough memory to hold 20 pointers of struct foobarbaz*/
    container = malloc(sizeof(struct foobarbaz*) * 20);
    if (container == NULL)
    {
        printf("ERROR: Out of memory!\n");
        exit(0);
    }

    /*At each index, initialize a foobarbaz structure*/
    int i;
    for (i = 0; i < 20; i++)
    {
        container[i] = rand_foobarbaz();
    }

    return container;
}