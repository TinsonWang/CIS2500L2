#include "functions.h"

void print_foobarbaz_array(struct foobarbaz** array)
{
    int i;
    printf("foo  bar    baz\n");
    for (i = 0; i < 20; i++)
    {
        printf("%.2d   %.2f   %.2d\n", array[i]->foo, array[i]->bar, array[i]->baz);
    }
}