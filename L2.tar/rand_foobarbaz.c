#include "functions.h"

struct foobarbaz* rand_foobarbaz(void)
{
    struct foobarbaz* p = NULL;
    p = malloc(sizeof(struct foobarbaz));
    if (p == NULL)
    {
        printf("ERROR: Out of memory!\n");
        exit(0);
    }
    (*p).foo = rand_double(0, 49);
    (*p).bar = rand_double(0.0, 100.0);
    (*p).baz = rand_double(50, 99);

    return p;
}