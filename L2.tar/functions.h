#include <stdio.h>
#include <stdlib.h>

struct foobarbaz
{
    int foo;
    double bar;
    int baz;
};

double rand_double(double a, double b);
struct foobarbaz* rand_foobarbaz(void);
struct foobarbaz** many_foobarbaz(void);
void print_foobarbaz_array (struct foobarbaz** array);
void swap_output(struct foobarbaz** array, int a, int b);

