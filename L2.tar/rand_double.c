#include "functions.h"

/*Generates a random number between a and b, inclusive*/
double rand_double(double a, double b)
{
    double c;

    if (b > a)
    {
        c = (((double) rand() / (double) RAND_MAX) * (b-a)) + a;
    }
    else if (b < a)
    {
        c = (((double) rand() / (double) RAND_MAX) * (a-b)) + b;
    }

    return c;
}