CIS*2500 Lab 2
Program by Tinson Wang, 0983887

Program takes in no input. An array of structures is created and printed. A swap is then performed on the array.
The array is then reprinted.

File names included in this submission:
1. main.c (where main() resides)
2. rand_double.c
3. rand_foobarbaz.c
4. many_foobarbaz.c
5. print_foobarbaz_array.c
6. swap_output.c
7. functions.h
8. Makefile
9. README.txt